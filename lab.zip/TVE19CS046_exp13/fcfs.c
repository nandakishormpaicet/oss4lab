#include <stdio.h>
#include <stdlib.h>

void main(){
    int n,head,distance=0;
    printf("Enter the number of requests : ");
    scanf("%d",&n);
    int request[n];
    printf("Enter the request sequence : ");
    for(int i=0;i<n;i++){
        scanf("%d",&request[i]);
    }
    printf("Enter the head position: ");
    scanf("%d",&head);
    printf("Seek Sequence : ");
    for(int i=0;i<n;i++){
        distance+=abs(head-request[i]);
        head=request[i];
        printf("%d ",request[i]);
    }
    printf("\nSeek Count = %d\n",distance);
}