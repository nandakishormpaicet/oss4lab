#include <stdio.h>
#include <stdlib.h>

void sort(int *arr,int n){
    for(int i=0;i<n-1;i++){
        int min_index=i;
        for(int j=i+1;j<n;j++){
            if(arr[j]<arr[min_index]){
                min_index=j;
            }
        }
        if(min_index!=i){
            int temp=arr[min_index];
            arr[min_index]=arr[i];
            arr[i]=temp;
        }
    }
}

void main(){
    int n,head,distance=0,max;
    printf("Enter the number of requests : ");
    scanf("%d",&n);
    int request[n];
    printf("Enter the request sequence : ");
    for(int i=0;i<n;i++){
        scanf("%d",&request[i]);
    }
    printf("Enter the head position: ");
    scanf("%d",&head);
    printf("Enter max track position: ");
    scanf("%d",&max);
    sort(request,n);
    int right,left;
    for(int i=0;i<n;i++){
        if(request[i]>=head){
            right=i;
            break;
        }
    }
    left=right-1;
    printf("Seek Sequence : ");
    for(int i=right;i<n;i++){
        printf("%d ",request[i]);
    }
    distance+=max-head+max;
    head=0;
    printf("%d %d ",max,head);
    for(int i=0;i<=left;i++){
        printf("%d ",request[i]);
    }
    distance+=request[left];
    printf("\nSeek Count = %d\n",distance);
}