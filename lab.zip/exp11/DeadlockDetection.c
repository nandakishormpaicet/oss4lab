#include <stdio.h>

int main()
{
	int n, r, flag;

	printf("Enter the number of processes : ");
	scanf("%d", &n);

	printf("Enter the number of resource types : ");
	scanf("%d", &r);

	int alloc[n][r], max[n][r], avail[r], finish[n], P[n];
	int ind = 0;

	printf("Enter the MAX matrix :\n");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < r; j++)
			scanf("%d", &max[i][j]);
	}

	printf("Enter the Allocation matrix :\n");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < r; j++)
			scanf("%d", &alloc[i][j]);
	}

	printf("Enter the available resources :\n");
	for (int i = 0; i < r; i++)
	{
		scanf("%d", &avail[i]);
	}

	for (int i = 0; i < n; i++)
		finish[i] = 0;

	int need[n][r];
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < r; j++)
			need[i][j] = max[i][j] - alloc[i][j];
	}

	for (int k = 0; k < n; k++)
	{
		for (int i = 0; i < n; i++)
		{
			if (finish[i] == 0)
			{
				flag = 0;
				for (int j = 0; j < r; j++)
				{
					if (need[i][j] > avail[j])
					{
						flag = 1;
						break;
					}
				}

				if (flag == 0)
				{
					P[ind++] = i;
					for (int y = 0; y < r; y++)
						avail[y] += alloc[i][y];
					finish[i] = 1;
					break;
				}
			}
		}
	}

	int dead[n], k = 0;
	flag = 0;
	for (int i = 0; i < n; i++)
	{
		if (finish[i] == 0)
		{
			dead[k] = i;
			k++;
			flag = 1;
		}
	}

	if (flag == 1)
	{
		printf("\nSystem is in Deadlock State and Deadlock process are: \n");
		for (int i = 0; i < k - 1; i++)
			printf("P%d, ", dead[i]);
		printf("P%d\n", dead[k - 1]);
	}
	else
	{
		printf("No Deadlock Occured\n");
		printf("The sequence of execution of processes is :\n");
		for (int i = 0; i < n - 1; i++)
			printf(" P%d ->", P[i]);
		printf(" P%d\n", P[n - 1]);
	}

	return (0);
}