echo -n "Enter the basic salary: "
read basic
if [ $basic -lt 1500 ]
then
    hra=`expr "scale=2; $basic * 0.1" | bc`
    da=`expr "scale=2; $basic * 0.9" | bc`
else
    hra=500
    da=`expr "scale=2; $basic * 0.98" | bc`
fi
gs=`expr "scale=2;$basic +$hra +$da" | bc`
echo "HRA =" $hra
echo "DA =" $da
echo "Gross Salary =" $gs