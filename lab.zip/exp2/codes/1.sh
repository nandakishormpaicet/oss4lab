if [ $# -eq 0 ]
    then 
    echo No arguments!
    exit
fi
for i in $*
do
    if [ -f $i ]
    then
        echo "File is valid"
        echo "Contents of $i before converting\n"
        cat $i
        echo "\nContents of $i after converting\n"
        tr [:lower:] [:upper:] < $i
        echo "\n"
    else
        echo File does not exist!
    fi
done