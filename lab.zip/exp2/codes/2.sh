#!/bin/bash
echo Number of arguments are $#
for ((i=$#;i>0;i--))
do
    res=$res' '"${!i}"

done
echo Arguments in reverse order $res