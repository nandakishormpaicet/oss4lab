echo -n "Enter first number: "
read a
echo -n "Enter second number: "
read b
echo -n "Enter third number: "
read c
if [ $a -eq $b -a $b -eq $c ] 
then 
    echo All numbers are equal
    exit
fi
if [ $a -lt $b ] 
then 
    s1=$a
else
    s1=$b
fi
if [ $s1 -gt $c ] 
then 
    s1=$c
fi
echo "\nSmallest number : " $s1