#!/bin/bash 
echo -n "Enter the range: "
read a
read b
f=0
echo -n "Armstrong numbers: "
for ((i=a;i<=b;i++))
do
    n=$i
    digits=${#n}
    sum=0
    while [ $n -gt 0 ]
    do
        rem=$[n%10]
        pow=$[rem**digits]
        sum=$[sum + pow]
        n=$[n/10]
    done
    
    if [ $sum -eq $i ]
    then 
        echo -n $i" "
        f=1
    fi
done
if [ $f -eq 0 ]
then
    echo None
fi
echo