for ((i=1;i<=3;i++))
do
    num=$i
    for ((j=0;j<=3;j++))
    do
        var=$[num*10 +j]
        for ((k=0;k<=3;k++))
        do
            echo $[var*10 +k]
        done
    done
done