echo -n "Enter a number: "
read n
p=$n
f=1
while [ 1 ]
do 
    p=$[p+1] 
    f=1   
    for ((i=2;i<=$[p/2];i++))
    do
        if [ $[p%i] -eq 0 ]
        then
            f=0
        fi        
    done
    if [ $p -le 1 ]
    then    
        f=0
    fi
    if [ $f -eq 1 ]
    then 
        sd=0
        rev=0
        num=$p
        while [ $num -gt 0 ]
        do
            sd=$[num % 10]
            rev=$[rev * 10 + sd]
            num=$[num/10]
        done
        if [ $rev -eq $p ]
        then 
            echo $p is the smallest prime number greater than $n which is palindromic.
            break
        fi
    fi
done