function summarize()
{
    echo "Number of files in the directory : $(find $1 -type f | wc -l)"
    echo "List of extensions and their count: "
    find $1 -type f | sed 's/.*\././' | sort | uniq -c
}