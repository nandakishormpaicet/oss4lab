echo -n "Enter a decimal number: "
read n
c=$(echo "obase=2;$n" | bc)
echo Binary: $c
h=$(echo "obase=16; $n"| bc)
echo Hexadecimal: $h