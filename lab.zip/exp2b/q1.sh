echo -n "Enter a password: "
read password
len="${#password}"
flag=0
if [ $len -ge 8 ]; then
    str=$(echo $password | grep [a-z] | grep [A-Z] | grep [0-9] | grep [_])
    if [ ! -z $str ]
    then
        echo Strong password
        flag=1
    fi
fi
if [ $flag -eq 0 ]
then
   echo Weak password
fi