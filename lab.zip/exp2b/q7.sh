echo -n "Enter n: "
read n
st=1
for ((i=$[n/2];i>=0;i--))
do
    if [ $st -le $n ]
    then
        for ((j=0;j<$i;j++))
        do
            echo -n "  "   
        done
    
        for ((k=1;k<=st;k++))
        do
            echo -n "* "
            
        done
        st=$[st+2]
        echo
    fi
done
st=$[st-2]
if [ $[n%2] -eq 1 ]
then
    st=$[st-2]
fi
for ((i=1;i<=$[n/2];i++))
do
    for ((j=1;j<=$i;j++))
    do
        echo -n "  "   
    done
   
    for ((k=1;k<=st;k++))
    do
        echo -n "* "
        
    done
    st=$[st-2]
    echo
done