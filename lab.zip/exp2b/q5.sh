file="./marks.txt"
while IFS=' ' read roll m1 m2 m3 
do 
    if [ $m1 -gt 50  -a $m2 -gt 50 -a $m3 -gt 50 ]
    then
        echo "$roll Passed"
    else
        echo "$roll Failed"
    fi
done < $file 