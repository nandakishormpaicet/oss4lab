#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//Nanda Kishor M Pai TVE19CS046
typedef struct process
{
    int pid, arrival, burst, wait, turn, type;
    int temp, started, quantum;
} process;
int k = 0;
int *pid;
int *time;

typedef struct queue
{
    process *p;
    struct queue *next;
} queue;

process *highestpriority_process(queue *q)
{
    queue *ptr = q->next;
    process *min = ptr->p;
    process *i;
    while (ptr != NULL)
    {
        i = ptr->p;
        if (min->type < i->type)
        {
            min = i;
        }
        ptr = ptr->next;
    }
    return min;
}

void enqueue(queue *q, process *p)
{
    queue *ptr = q;
    while (ptr->next != NULL)
    {
        ptr = ptr->next;
    }
    queue *newPtr = (queue *)malloc(sizeof(queue));
    newPtr->next = NULL;
    newPtr->p = p;
    ptr->next = newPtr;
}

process *dequeue(queue *q)
{
    process *i = highestpriority_process(q);
    process *p = NULL;
    queue *ptr = q->next;
    queue *prev = NULL;
    while (ptr != NULL)
    {
        if (ptr->p == i)
        {
            p = i;
            if (prev != NULL)
            {
                prev->next = ptr->next;
            }
            else
            {
                q->next = ptr->next;
            }
            free(ptr);
            ptr = NULL;
            return p;
        }
        prev = ptr;
        ptr = ptr->next;
    }
    return p;
}

void sort_arrival_time(process *p, int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        int min = i;
        for (int j = i + 1; j < n; j++)
        {
            if (p[min].arrival > p[j].arrival)
                min = j;
            if (p[min].arrival == p[j].arrival)
            {
                if (p[min].type < p[j].type)
                {
                    min = j;
                }
            }
        }
        if (i != min)
        {
            process temp = p[i];
            p[i] = p[min];
            p[min] = temp;
        }
    }
}

void roundrobin(process *p, int n)
{
    int total_time = 0;
    process *current;
    queue *q = (queue *)malloc(sizeof(queue));
    enqueue(q, &p[0]);
    p[0].started = 1;
    while (1)
    {
        current = dequeue(q);
        if (current->temp >= current->quantum)
        {
            current->temp -= current->quantum;
            total_time += current->quantum;
        }
        else
        {
            total_time += current->temp;
            current->temp = 0;
        }
        pid[k] = current->pid;
        time[k++] = total_time;

        for (int i = 0; i < n; i++)
        {
            if ((p[i].started == 0) && (p[i].arrival <= total_time))
            {
                enqueue(q, &p[i]);
                p[i].started = 1;
            }
        }
        if (current->temp > 0)
        {
            enqueue(q, current);
        }
        else
        {
            current->turn = total_time - current->arrival;
            current->wait = current->turn - current->burst;
        }

        if (q->next == NULL)
        {
            break;
        }
    }
}

void table(process *p, int n, int size)
{
    printf("\n");
    printf("Process ID      Time Taken\n");
    for (int i = 0; i < size; i++)
    {
        if (i == 0)
        {
            printf("   P%d             %d-%d\n", pid[i], p[0].arrival, time[i]);
        }
        else
        {
            printf("   P%d             %d-%d\n", pid[i], time[i - 1], time[i]);
        }
    }
    printf("\n");
}

void average(process *p, int n)
{
    float w_sum = 0;
    for (int i = 0; i < n; i++)
    {
        w_sum += p[i].wait;
    }
    printf("\nAverage Waiting Time = %0.3f\n", w_sum / n);
}

void main()
{
    int n, size = 0;
    process *p;
    printf("Enter the number of processes: ");
    scanf("%d", &n);
    p = (process *)malloc(sizeof(process) * n);
    printf("\nEnter the process id, arrival time, burst time and process type of Processes\n");
    printf("For process type, input 1 for SYSTEM and 0 for USER\n");
    for (int i = 0; i < n; i++)
    {
        scanf("%d%d%d%d", &p[i].pid, &p[i].arrival, &p[i].burst, &p[i].type);
        p[i].temp = p[i].burst;
        p[i].started = 0;
        if (p[i].type != 0 && p[i].type != 1)
        {
            printf("Invalid process type!!\n");
            exit(0);
        }
        float f;
        if (p[i].type == 1)
        {
            p[i].quantum = 5;
            f = p[i].burst / (float)5;
        }
        else
        {
            p[i].quantum = 2;
            f = p[i].burst / (float)2;
        }
        size += ceil(f);
    }
    pid = (int *)malloc(sizeof(int) * size);
    time = (int *)malloc(sizeof(int) * size);
    sort_arrival_time(p, n);
    roundrobin(p, n);
    printf("\n\t\t\tROUND ROBIN SCHEDULING (Sorted based on arrival time)\n");
    printf("Process ID   Arrival time   Burst time       Process Type    Waiting time    Turnaround Time\n");
    printf("---------   ------------   ----------        ------------    ------------    ---------------\n");
    for (int i = 0; i < n; i++)
    {
        printf("    P%d\t\t%d\t\t%d\t\t", p[i].pid, p[i].arrival, p[i].burst);
        if (p[i].type == 1)
        {
            printf("SYSTEM");
        }
        else
        {
            printf("USER");
        }
        printf("\t\t%d\t\t%d\n", p[i].wait, p[i].turn);
    }
    table(p, n, size);
    average(p, n);
}