#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t *chopsticks;
int n;

void *philos(void *philo)
{
    int ph = *(int *)philo;
    
    sem_wait(&chopsticks[ph]);
    printf("Philosopher %d picks up left chopstick\n", ph);
    sem_wait(&chopsticks[(ph + 1) % n]);
    printf("Philosopher %d picks up right chopstick\n", ph);
    printf("Philosopher %d is eating\n", ph);
    sleep(2);
    printf("Philosopher %d has finished eating\n", ph);
    sem_post(&chopsticks[(ph + 1) % n]);
    printf("Philosopher %d puts down right chopstick\n", ph);
    sem_post(&chopsticks[ph]);
    printf("Philosopher %d puts down left chopsticks\n", ph);
    printf("Philosopher %d is thinking\n",ph);
}

int main()
{
    printf("Enter the number of philosophers : ");
    scanf("%d",&n);
    printf("\n");
    chopsticks =malloc(sizeof(sem_t)*n);
    int *philo=malloc(sizeof(int)*n);
    int i;
    pthread_t *T=malloc(sizeof(pthread_t)*n);
    for (i = 0; i < n; i++)
        sem_init(&chopsticks[i], 0, 1);
    for (i = 0; i < n; i++){
        philo[i]=i;
        pthread_create(&T[i], NULL, philos, (void *)&philo[i]);
    }
    for (i = 0; i < n; i++)
        pthread_join(T[i], NULL);
}
