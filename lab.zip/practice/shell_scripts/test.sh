#!/bin/sh

echo "hello"
read EMPLOYEE
echo "$EMPLOYEE"
