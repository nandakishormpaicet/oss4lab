#!/bin/sh
#variable_nae=variahle_value
NAME="Raues"
echo $NAME

