#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
void main()
{
    struct dirent *dp;
    struct stat sfile;
    DIR *p;
    char buff[100];
    printf("Enter directory name: ");
    scanf("%s", buff);
    p = opendir(buff);
    if (p == NULL)
    {
        printf("Directory does not exist\n");
        exit(1);
    }
    dp = readdir(p);
    while (dp != NULL)
    {
        stat(dp->d_name, &sfile);
        printf("\nFile name : %s\n", dp->d_name);
        printf("dir = %d\n", S_ISDIR(sfile.st_mode));
        printf("File size in bytes : %ld\n", sfile.st_size);
        printf("Last modified time in seconds : %ld \n",sfile.st_mtime);
        printf("Last access time in seconds : %ld \n",sfile.st_atime);
        printf("The device containing the file : %ld\n", sfile.st_dev);
        printf("File serial number : %ld\n", sfile.st_ino);
        dp = readdir(p);
    }
    closedir(p);
}