#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
void main(int argc,char *argv[])
{
    printf("In exec.c\n");
    for(int i=0;i<argc;i++){
        printf("%s ",argv[i]);
    }
    printf("\nPID of exec.c is %d\n",getpid());
}