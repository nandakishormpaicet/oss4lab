#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    char file[100];
    printf("Enter a filename: ");
    scanf("%s",file);
    int fd = open(file, O_RDONLY);
    if (fd < 0) 
    {
        printf("Failed to open\n");
        printf("Exiting..\n");
        exit(1);
    }
    printf("opened the file descriptor\nfd = % d\n", fd);
      
    if (close(fd) < 0) 
    {
        printf("Failed to close");
        exit(1);
    } 
    printf("Closed the file descriptor.\n");
    
}