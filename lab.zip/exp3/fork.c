#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/wait.h>

void main()
{
    int pid;
    for (int i = 0; i < 2; i++)
    {
        pid = fork();
        if (pid < 0)
        {
            printf("Fork failed");
            exit(1);
        }
        else if (pid != 0)
        {
            wait(NULL);
            printf("Parent process id is %d\n", getpid());   
        }
        else
        {
            printf("Child process id is %d\n", getpid());   
            char *args[] = {"Hello", "World", NULL};
            execv("./exec", args);      
        }
    }
}