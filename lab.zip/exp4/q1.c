#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

int main()
{
    int inFile;
    int n_char = 0;
    char buffer[10], file[50];
    printf("Enter a filename: ");
    scanf("%s", file);
    inFile = open(file, O_RDONLY);
    if (inFile == -1)
    {
        printf("File does not exist.\n");
        exit(1);
    }
    else
        printf("\nOpened %s\n", file);

    printf("Reading %s and writing to standard output...\n\n", file);
    while ((n_char = read(inFile, buffer, 10)) != 0)
    {
        n_char = write(1, buffer, n_char);
    }

    int c = close(inFile);
    if (c == 0)
        printf("\n\nClosed %s\n", file);
    return 0;
}